/* =====================================================================
   Thandi's Hair & Beauty Studio - Part 3 JavaScript
   Works with the existing Part 2 HTML and CSS (no HTML/CSS edits needed).
   Add this line just before </body> on EVERY page:
       <script src="Javascript/main.js"></script>
   ===================================================================== */
(() => {
  'use strict';
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const make = (tag, props = {}, html = '') => {
    const el = Object.assign(document.createElement(tag), props);
    if (html) el.innerHTML = html;
    return el;
  };

  /* ---------- Small stylesheet for the elements this script adds ---------- */
  const style = make('style');
  style.textContent = `
    .reveal{opacity:0;transform:translateY(24px);transition:opacity .6s ease,transform .6s ease}
    .reveal.visible{opacity:1;transform:none}
    .js-controls{display:grid;grid-template-columns:2fr 1fr 1fr;gap:1rem;background:#fff;padding:1.2rem 1.4rem .4rem;
      border-radius:10px;box-shadow:0 4px 12px rgba(62,43,32,.08);border-left:5px solid #a1887f;margin-bottom:1rem}
    .js-count{margin:.2rem 0 1.2rem;font-size:.9rem;color:#6d4c41}
    .js-book{display:inline-block;align-self:flex-start;margin-top:.5rem;padding:.45rem 1.1rem;border-radius:25px;
      background:#6d4c41;color:#fff!important;font-size:.9rem;border-bottom:none!important}
    .js-book:hover{background:#4e342e}
    .accordion-btn{width:100%;text-align:left;background:none;border:none;cursor:pointer;padding:1rem 2.5rem 1rem 0;
      position:relative;font:600 1rem inherit;font-family:inherit;color:#4e342e;border-bottom:1px solid #d7ccc8}
    .accordion-btn::after{content:'+';position:absolute;right:.4rem;top:50%;transform:translateY(-50%);font-size:1.5rem;transition:transform .3s}
    .accordion-btn[aria-expanded="true"]::after{transform:translateY(-50%) rotate(45deg)}
    .accordion-btn:focus-visible{outline:3px solid #a1887f;outline-offset:2px}
    .accordion-panel{display:grid;grid-template-rows:0fr;visibility:hidden;transition:grid-template-rows .3s ease,visibility .3s}
    .accordion-panel.open{grid-template-rows:1fr;visibility:visible}
    .accordion-panel>div{overflow:hidden}.accordion-panel p{padding:.8rem 0}
    .gallery-item{cursor:zoom-in}
    dialog.lightbox{border:none;background:transparent;max-width:min(92vw,900px);width:100%;padding:0;overflow:visible;margin:auto}
    dialog.lightbox::backdrop{background:rgba(0,0,0,.88)}
    .lightbox figure{text-align:center}.lightbox img{max-width:100%;max-height:75vh;border-radius:10px}
    .lightbox figcaption{color:#fff;margin-top:.8rem}
    .lb-btn{position:absolute;background:rgba(255,255,255,.9);color:#4e342e;border:none;width:2.6rem;height:2.6rem;
      border-radius:50%;font-size:1.6rem;line-height:1;cursor:pointer}
    .lb-btn:hover,.lb-btn:focus-visible{background:#fff;outline:3px solid #a1887f}
    .lb-close{top:-3rem;right:0}.lb-prev{left:.5rem;top:45%}.lb-next{right:.5rem;top:45%}
    #map{width:100%;height:350px;border-radius:10px;margin-bottom:1.5rem;z-index:1}
    .field-error{display:block;min-height:1.1em;color:#b3261e;font-size:.8rem;margin-top:.25rem}
    .is-invalid{border-color:#b3261e!important;background:#fff6f5!important}
    .form-status{margin-top:1rem;font-size:.9rem}
    .form-status.success{padding:.8rem 1rem;border-radius:6px;background:#e6f4ea;color:#1e5d2f;border:1px solid #a8d5b4}
    .form-status.error{padding:.8rem 1rem;border-radius:6px;background:#fdecea;color:#8a1c14;border:1px solid #f1b0ab}
    .open-badge{display:inline-block;margin:.6rem 0 0;padding:.3rem .9rem;border-radius:25px;font-size:.85rem;font-weight:600}
    .open-badge.open{background:#e6f4ea;color:#1e5d2f}.open-badge.closed{background:#fdecea;color:#8a1c14}
    .nav-toggle{display:none}
    @media(max-width:900px){.js-controls{grid-template-columns:1fr}}
    @media(max-width:700px){
      .nav-toggle{display:block;background:none;border:2px solid #fff;color:#fff;padding:.4rem .9rem;border-radius:25px;font:600 .9rem inherit;cursor:pointer}
      nav{justify-content:flex-start!important}
      nav a{display:none!important;width:100%;text-align:center}
      nav.open a{display:block!important}
    }
    @media(prefers-reduced-motion:reduce){.reveal{opacity:1;transform:none;transition:none}*{animation:none!important}}
  `;
  document.head.append(style);

  /* ---------- 1. Mobile navigation toggle ---------- */
  const nav = $('nav');
  if (nav) {
    const btn = make('button', { type: 'button', className: 'nav-toggle', textContent: '\u2630 Menu' });
    btn.setAttribute('aria-expanded', 'false');
    btn.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', String(open));
    });
    nav.prepend(btn);
    const here = location.pathname.split('/').pop().toLowerCase() || 'home.html';
    $$('a', nav).forEach(a => {
      if (a.getAttribute('href').toLowerCase() === here) {
        a.classList.add('active');
        a.setAttribute('aria-current', 'page');
      }
    });
  }

  /* ---------- 2. Scroll-reveal animation (CSS transition + IntersectionObserver) ---------- */
  const io = 'IntersectionObserver' in window
    ? new IntersectionObserver(entries => entries.forEach(e => {
        if (!e.isIntersecting) return;
        e.target.classList.add('visible');
        io.unobserve(e.target);
        // remove helper classes afterwards so the site's own hover effects keep working
        setTimeout(() => e.target.classList.remove('reveal', 'visible'), 700);
      }), { threshold: 0.1 })
    : null;
  const reveal = els => els.forEach(el => {
    if (!io) return;
    el.classList.add('reveal');
    io.observe(el);
  });
  reveal($$('.feature-box, .service-card, .gallery-item, .value-item, .about-content, .contact-info, .contact-form, main section'));

  /* ---------- 3. "Open now" badge (dynamic DOM content) ---------- */
  const heading = $('main h1') || $('h1');
  if (heading && ($('.contact-info') || $('#home-page-images-div'))) {
    const hours = { 1: [9, 18], 2: [9, 18], 3: [9, 18], 4: [9, 18], 5: [9, 18], 6: [9, 15] }; // Sunday closed
    const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Africa/Johannesburg' }));
    const h = hours[now.getDay()];
    const hour = now.getHours() + now.getMinutes() / 60;
    const isOpen = h && hour >= h[0] && hour < h[1];
    const badge = make('p', { className: 'open-badge ' + (isOpen ? 'open' : 'closed') },
      isOpen ? `\u25CF Open now until ${h[1]}:00` : '\u25CF Closed now - see opening hours on the Contact page');
    badge.setAttribute('role', 'status');
    heading.after(badge);
  }

  /* ---------- 4. Services page: search, sort, filter + FAQ accordion ---------- */
  const grid = $('.services-grid');
  if (grid) {
    const cards = $$('.service-card', grid);
    const idByWord = { facial: 'facial', makeup: 'makeup', nail: 'nails', lash: 'lash', hair: 'hair', massage: 'massage' };
    const info = cards.map(card => {
      const name = $('h3', card).textContent.trim();
      const price = parseInt($('.price', card).textContent.replace(/\D/g, ''), 10) || 0;
      const key = Object.keys(idByWord).find(k => name.toLowerCase().includes(k));
      // "Book this service" link that pre-selects the service on the contact form
      const link = make('a', { className: 'js-book', href: 'contact.html?service=' + (idByWord[key] || 'other'), textContent: 'Book this service' });
      $('.service-info', card).append(link);
      return { card, name, price, text: card.textContent.toLowerCase() };
    });

    const controls = make('div', { className: 'js-controls', role: 'search' }, `
      <div class="form-group"><label for="js-search">Search services</label>
        <input type="text" id="js-search" placeholder="e.g. nails, braids, facial" autocomplete="off"></div>
      <div class="form-group"><label for="js-price">Price</label>
        <select id="js-price"><option value="0">Any price</option><option value="250">Up to R250</option>
          <option value="400">Up to R400</option><option value="500">Up to R500</option></select></div>
      <div class="form-group"><label for="js-sort">Sort by</label>
        <select id="js-sort"><option value="default">Default order</option><option value="name">Name (A-Z)</option>
          <option value="asc">Price (low to high)</option><option value="desc">Price (high to low)</option></select></div>`);
    const count = make('p', { className: 'js-count' });
    count.setAttribute('aria-live', 'polite');
    grid.before(controls, count);

    const search = $('#js-search'), price = $('#js-price'), sort = $('#js-sort');
    const update = () => {
      const q = search.value.trim().toLowerCase(), max = +price.value;
      const sorters = {
        name: (a, b) => a.name.localeCompare(b.name),
        asc: (a, b) => a.price - b.price,
        desc: (a, b) => b.price - a.price,
        default: () => 0
      };
      let shown = 0;
      [...info].sort(sorters[sort.value]).forEach(s => {
        const match = (!q || s.text.includes(q)) && (!max || s.price <= max);
        s.card.style.display = match ? '' : 'none';
        if (match) shown++;
        grid.append(s.card); // re-append in sorted order
      });
      count.textContent = shown
        ? `Showing ${shown} of ${info.length} services`
        : 'No services match your search. Try another word or change the price filter.';
    };
    [search, price, sort].forEach(el => el.addEventListener('input', update));
    update();

    // FAQ accordion, built from data and inserted under the services
    const faq = [
      ['How do I book an appointment?', 'Use the "Book this service" button, send an enquiry on the Contact page, or message us on WhatsApp. We confirm your slot by phone, WhatsApp or email.'],
      ['Are the prices fixed?', 'Prices shown are starting prices. The final price depends on hair length, style complexity and products used, and we confirm it before your appointment.'],
      ['What are your opening hours?', 'Monday to Friday 09:00-18:00 and Saturday 09:00-15:00. We are closed on Sundays.'],
      ['Can I cancel or reschedule?', 'Yes. Please let us know at least 24 hours ahead so we can offer the slot to another client.']
    ];
    const section = make('section', {}, '<h2>Frequently Asked Questions</h2>');
    faq.forEach(([q, a], i) => {
      section.append(make('div', {}, `
        <h3 style="font-size:1rem;margin:0"><button class="accordion-btn" type="button" aria-expanded="false" aria-controls="faq-${i}">${q}</button></h3>
        <div class="accordion-panel" id="faq-${i}"><div><p>${a}</p></div></div>`));
    });
    section.addEventListener('click', e => {
      const btn = e.target.closest('.accordion-btn');
      if (!btn) return;
      const open = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!open));
      $('#' + btn.getAttribute('aria-controls')).classList.toggle('open', !open);
    });
    grid.closest('main').append(section);
    reveal([section]);
  }

  /* ---------- 5. Gallery lightbox (native <dialog>) ---------- */
  const items = $$('.gallery-item').filter(i => $('img', i));
  if (items.length && 'HTMLDialogElement' in window) {
    const dlg = make('dialog', { className: 'lightbox' }, `
      <button class="lb-btn lb-close" aria-label="Close image viewer">&times;</button>
      <button class="lb-btn lb-prev" aria-label="Previous image">&#8249;</button>
      <figure><img alt=""><figcaption></figcaption></figure>
      <button class="lb-btn lb-next" aria-label="Next image">&#8250;</button>`);
    dlg.setAttribute('aria-label', 'Image viewer');
    document.body.append(dlg);
    const img = $('img', dlg), cap = $('figcaption', dlg);
    let idx = 0;
    const show = i => {
      idx = (i + items.length) % items.length;
      const el = items[idx], pic = $('img', el);
      img.src = pic.currentSrc || pic.src;
      img.alt = pic.alt;
      const t = $('h4', el), d = $('p', el);
      cap.textContent = [t && t.textContent, d && d.textContent].filter(Boolean).join(' - ');
    };
    items.forEach((el, i) => {
      el.tabIndex = 0;
      el.setAttribute('role', 'button');
      el.setAttribute('aria-label', 'Enlarge image: ' + ($('h4', el) ? $('h4', el).textContent : $('img', el).alt));
      const open = () => { show(i); dlg.showModal(); };
      el.addEventListener('click', open);
      el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
    });
    $('.lb-close', dlg).addEventListener('click', () => dlg.close());
    $('.lb-prev', dlg).addEventListener('click', () => show(idx - 1));
    $('.lb-next', dlg).addEventListener('click', () => show(idx + 1));
    dlg.addEventListener('click', e => { if (e.target === dlg) dlg.close(); });
    dlg.addEventListener('keydown', e => {
      if (e.key === 'ArrowRight') show(idx + 1);
      if (e.key === 'ArrowLeft') show(idx - 1);
    });
  }

  /* ---------- 6. Contact page: Leaflet map (replaces the Google iframe) ---------- */
  const iframe = $('iframe[src*="google.com/maps"]');
  if (iframe || $('.contact-form')) {
    const mapDiv = make('div', { id: 'map' });
    mapDiv.setAttribute('role', 'region');
    mapDiv.setAttribute('aria-label', "Map showing Thandi's Hair & Beauty Studio in Diepsloot Crossing");
    if (iframe) iframe.replaceWith(mapDiv); else $('main').prepend(mapDiv);

    const css = make('link', { rel: 'stylesheet', href: 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css' });
    const js = make('script', { src: 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js' });
    js.onload = () => {
      // Approximate position of Diepsloot Crossing - confirm exact coordinates before publishing.
      const pos = [-25.9318, 28.0108];
      const map = L.map(mapDiv).setView(pos, 15);
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);
      L.marker(pos).addTo(map)
        .bindPopup("<strong>Thandi's Hair &amp; Beauty Studio</strong><br>Diepsloot Crossing, Diepsloot").openPopup();
    };
    document.head.append(css);
    document.body.append(js);
  }

  /* ---------- 7. Contact form: validation + AJAX submit ---------- */
  const form = $('.contact-form form');
  if (form) {
    form.noValidate = true;
    const rules = {
      name: v => v.trim().length >= 2 || 'Please enter your full name (at least 2 characters).',
      email: v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) || 'Please enter a valid email address, e.g. name@example.com.',
      service: v => v !== '' || 'Please choose a service.',
      message: v => v.trim().length >= 10 || 'Please tell us a little more (at least 10 characters).'
    };
    const fields = Object.keys(rules).map(id => document.getElementById(id)).filter(Boolean);

    fields.forEach(f => {
      const err = make('span', { className: 'field-error', id: f.id + '-error' });
      err.setAttribute('role', 'alert');
      f.after(err);
      f.setAttribute('aria-describedby', err.id);
    });
    const status = make('p', { className: 'form-status', tabIndex: -1 });
    status.setAttribute('role', 'status');
    form.append(status);

    const check = f => {
      const r = rules[f.id](f.value);
      const bad = r !== true;
      $('#' + f.id + '-error').textContent = bad ? r : '';
      f.classList.toggle('is-invalid', bad);
      f.setAttribute('aria-invalid', String(bad));
      return !bad;
    };
    fields.forEach(f => {
      f.addEventListener('blur', () => check(f));
      f.addEventListener('input', () => { if (f.classList.contains('is-invalid')) check(f); });
    });

    // Pre-select the service when arriving from "Book this service"
    const wanted = new URLSearchParams(location.search).get('service');
    const sel = document.getElementById('service');
    if (wanted && sel && $(`option[value="${wanted}"]`, sel)) sel.value = wanted;

    form.addEventListener('submit', async e => {
      e.preventDefault();
      status.className = 'form-status';
      status.textContent = '';
      const ok = fields.map(check).every(Boolean);
      if (!ok) {
        status.classList.add('error');
        status.textContent = 'Please fix the highlighted fields and try again.';
        $('.is-invalid', form).focus();
        return;
      }
      const btn = $('button[type="submit"]', form);
      const label = btn.textContent;
      btn.disabled = true; btn.textContent = 'Sending...';
      // The Part 2 form has action="#". Replace it with a Formspree URL to really receive messages.
      const demo = !form.getAttribute('action') || form.getAttribute('action') === '#';
      try {
        if (demo) {
          await new Promise(r => setTimeout(r, 800));
        } else {
          const res = await fetch(form.action, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } });
          if (!res.ok) throw new Error('HTTP ' + res.status);
        }
        status.classList.add('success');
        status.textContent = `Thank you, ${$('#name').value.trim().split(' ')[0]}! Your message has been sent and we will reply soon.` +
          (demo ? ' (Demo mode - connect a form service such as Formspree to receive messages.)' : '');
        form.reset();
      } catch (err) {
        status.classList.add('error');
        status.textContent = 'Sorry, something went wrong. Please try again or contact us by phone.';
      } finally {
        btn.disabled = false; btn.textContent = label;
        status.focus();
      }
    });
  }
})();