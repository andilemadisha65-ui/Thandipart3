# Thandi's Hair & Beauty Studio

Multi-page website for **Thandi's Hair & Beauty Studio**, an independent salon in Diepsloot Crossing, Johannesburg.
WEDE5020 POE - **Part 3: Enhancing Functionality and SEO**. Student: ST10521209.

- **Live site:** https://andilemadisha65-ui.github.io/Thandi-s-Hair-beauty-Studio/ *(update if you deploy elsewhere)*
- **Repository:** https://github.com/andilemadisha65-ui/Thandi-s-Hair-beauty-Studio

## Pages

| Page | File | Purpose |
|---|---|---|
| Home | `index.html` | Introduction, offer summary, calls to action |
| About | `about.html` | Story, values |
| Services | `services.html` | Searchable / filterable / sortable services, FAQ accordion |
| Gallery | `gallery.html` | Photo grid with lightbox |
| Contact | `contact.html` | Leaflet map, hours, validated enquiry/booking form |

## Part 3 features

**JavaScript (`Javascript/main.js`)**
- **Accordion** - FAQ on the Services page (keyboard accessible, `aria-expanded`).
- **Lightbox modal** - Gallery images open in a native `<dialog>` with previous/next, arrow keys, Esc and click-outside to close.
- **Interactive map** - Leaflet + OpenStreetMap on the Contact page with a marker and popup.
- **Animations** - CSS fade-up on the hero, scroll-reveal using `IntersectionObserver`, hover transitions; all disabled for users who prefer reduced motion.
- **DOM manipulation / dynamic content** - Service cards are generated from a JavaScript data array.
- **Search, filter and sort** - Services can be searched by keyword, filtered by category and sorted by name or price.
- **Form validation** - Client-side validation with inline, accessible error messages (`role="alert"`, `aria-invalid`), South African phone format check, no past or Sunday dates.
- **AJAX submission** - The form posts with `fetch()` and shows success/error feedback without reloading.
- **Mobile menu** and **service pre-selection** (`contact.html?service=hair`).

**HTML forms** - text, email, tel, select, date, radio group, textarea, checkbox consent, `<label>`s, `required`, `action`/`method`, hidden honeypot field.

**SEO**
- Unique `<title>` and meta description per page, canonical URLs, Open Graph / Twitter tags.
- One `<h1>` per page with logical `<h2>`/`<h3>` order.
- Descriptive image file names and meaningful `alt` text; images compressed and lazy-loaded.
- Clean, lowercase URLs (`index.html`, `about.html`, ...); internal links between pages.
- Mobile-friendly: viewport tag, responsive CSS, mobile navigation.
- `robots.txt` and `sitemap.xml`.
- Local SEO: `HairSalon` JSON-LD structured data (address, phone, hours), consistent name/address/phone, embedded map.
- Social: Open Graph tags, share links in the footer, WhatsApp button.

**Off-page SEO plan (not code)**
- *Keywords targeted:* hair salon Diepsloot, beauty studio Diepsloot, braids and weaves Diepsloot, nails Johannesburg north, book hair appointment Johannesburg.
- *Backlinks:* Google Business Profile, Booksy and local directories (Yellow Pages SA, Cylex), Diepsloot community Facebook groups, links from the owner's Instagram bio.
- *Social media:* Post gallery photos with the site link and UTM tags (`?utm_source=instagram`).
- *Local SEO:* Complete and verify the Google Business Profile with the same address, phone and hours as the site; ask happy clients for Google reviews.

## Setup

1. Open `index.html` in a browser (an internet connection is needed for fonts, map tiles and Services page photos).
2. **Form delivery:** create a free form at https://formspree.io and replace `your-form-id` in the `action` attribute of `#contact-form` in `contact.html`. Until then the form runs in demo mode and shows a "Demo mode" note.
3. Confirm the real street address, phone number and map coordinates (`pos` in `main.js`, currently approximate) before publishing.

## Deployment (GitHub Pages)

Repository **Settings > Pages > Deploy from a branch > `main` / root**. Update the URLs in `sitemap.xml`, `robots.txt`, canonical and Open Graph tags if the address differs.

## Changelog

### Part 3 (October 2026)

**Feedback edits from Part 2**
- `index.html` (was `Home.html`): rebuilt the broken document structure (stray `>` in `lang`, `<body>` inside `<head>`, orphan `</header>`/`</head>`, missing meta charset and viewport, malformed `<h1>`, `height;100px` typo). Removed the duplicate heading. Corrected typos ("beauutivian") and "moved from services" to "moved from home service" to match the Part 1 brief.
- `about.html`, `contact.html`: replaced the invalid `<header>` wrapped around `<meta>` tags with a proper `<head>`; added missing viewport tag on Contact.
- `services.html`, `gallery.html`: fixed the swapped/misplaced closing `</main>` and `</section>` tags.
- Navigation: links used `about.html`/`services.html`/`gallery.html` while the files were capitalised, which breaks on case-sensitive hosting. Files and links are now consistently lowercase.
- `contact.html`: the embedded Google Map pointed to "F45 Training Rosebank", not the studio; replaced with a Leaflet map of Diepsloot Crossing. Fixed stray `</div>` tags and the unlabelled `<main>` layout.
- `gallery.html`: the first gallery item had no image; replaced with a studio photo ("Our Studio") and added alt text to all images.
- `CSS/style.css`: the Google Fonts `@import` came after other rules, so browsers ignored it and the fonts never loaded; moved to the top. Removed a duplicated reset rule.
- Contact details are now clickable (`tel:` and `mailto:`).
- *(Add any specific lecturer feedback from the Part 2 marks sheet here.)*

**New in Part 3**
- Added `Javascript/main.js` with all interactive features listed above.
- Added Book Now button in the nav, sticky WhatsApp button, skip-to-content link, hero CTAs and CTA bands on every page.
- Services data moved into JavaScript; added search, category filter, sort, result count and "Book this service" links.
- Contact form extended with phone, date, reply preference and consent fields, plus validation and AJAX submission.
- SEO: page titles, meta descriptions, canonical, Open Graph, JSON-LD, `robots.txt`, `sitemap.xml`.
- Renamed and compressed all images (e.g. `images (2).jpg` to `nail-art-manicure.jpg`, 2326px original to 1000px).
- CSS: nav toggle, buttons, accordion, lightbox, form error states, animations, reduced-motion support.

## References

- Leaflet. (2023). *Leaflet: an open-source JavaScript library for mobile-friendly interactive maps* (v1.9.4). https://leafletjs.com
- OpenStreetMap contributors. *OpenStreetMap*. https://www.openstreetmap.org/copyright
- MDN Web Docs. *`<dialog>`: The Dialog element*. https://developer.mozilla.org/en-US/docs/Web/HTML/Element/dialog
- MDN Web Docs. *Intersection Observer API*. https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API
- MDN Web Docs. *Using the Fetch API*. https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
- Google Search Central. *SEO Starter Guide*, *Robots.txt introduction*, *Build and submit a sitemap*, *LocalBusiness structured data*. https://developers.google.com/search
- Schema.org. *HairSalon*. https://schema.org/HairSalon
- Formspree. *Formspree documentation*. https://help.formspree.io
- W3C. *Web Content Accessibility Guidelines (WCAG) 2.2*. https://www.w3.org/TR/WCAG22/
- Unsplash. Service-card photos on the Services page. https://unsplash.com
- Salon and gallery photographs: third-party images (some sourced from Booksy listings) - **replace with the studio's own photos or confirm licence/permission before final publication.**
